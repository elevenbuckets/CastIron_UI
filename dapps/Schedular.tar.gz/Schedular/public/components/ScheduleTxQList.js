'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _CastIronStore = require('../../../../public/store/CastIronStore');

var _CastIronStore2 = _interopRequireDefault(_CastIronStore);

var _reflux = require('reflux');

var _reflux2 = _interopRequireDefault(_reflux);

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _CastIronActions = require('../../../../public/action/CastIronActions');

var _CastIronActions2 = _interopRequireDefault(_CastIronActions);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Reflux components

class ScheduleTxQList extends _reflux2.default.Component {
  constructor(props) {
    super(props);

    this.render = () => {
      if (this.state.address == '') return _react2.default.createElement('p', null);

      let tokenBalances = [];
      let tokenkinds = 0;
      this.state.tokenList.map(t => {
        tokenBalances.push(t + ': ' + this.state.balances[t]);
        if (this.state.balances[t] > 0) tokenkinds++;
      });

      return _react2.default.createElement(
        'div',
        { style: { overflow: 'scroll', margin: '0', maxHeight: "430", height: '430px' } },
        _react2.default.createElement(
          'table',
          { className: 'txform' },
          _react2.default.createElement(
            'tbody',
            null,
            _react2.default.createElement(
              'tr',
              null,
              _react2.default.createElement(
                'td',
                { className: 'txform', width: '3%' },
                'X'
              ),
              _react2.default.createElement(
                'td',
                { className: 'txform', width: '32%' },
                'From'
              ),
              _react2.default.createElement(
                'td',
                { className: 'txform', width: '32%' },
                'To'
              ),
              _react2.default.createElement(
                'td',
                { className: 'txform', width: '4%' },
                'Type'
              ),
              _react2.default.createElement(
                'td',
                { className: 'txform', width: '10%' },
                'Amount'
              ),
              _react2.default.createElement(
                'td',
                { className: 'txform', width: '10%' },
                'Gas Fee'
              ),
              _react2.default.createElement(
                'td',
                { className: 'txform' },
                'Actions'
              )
            ),
            this.state.scheduleQueuedTxs.map(tx => {
              return _react2.default.createElement(
                'tr',
                null,
                _react2.default.createElement(
                  'td',
                  { className: 'txform', width: '5%' },
                  _react2.default.createElement('input', { type: 'button', className: 'xbutton', value: 'X',
                    onClick: this.handleDequeueSchedule.bind(this, tx) })
                ),
                _react2.default.createElement(
                  'td',
                  { className: 'txform', width: '32%' },
                  tx.from
                ),
                _react2.default.createElement(
                  'td',
                  { className: 'txform', width: '32%' },
                  tx.to
                ),
                _react2.default.createElement(
                  'td',
                  { className: 'txform', width: '4%' },
                  tx.type
                ),
                _react2.default.createElement(
                  'td',
                  { className: 'txform', width: '10%' },
                  tx.amount
                ),
                _react2.default.createElement(
                  'td',
                  { className: 'txform', width: '10%' },
                  tx.gas * this.state.gasPrice
                ),
                _react2.default.createElement(
                  'td',
                  { className: 'txform' },
                  _react2.default.createElement('input', { type: 'button', className: 'button', value: 'Schedule',
                    onClick: this.handScheduleTxInQueue.bind(this, tx) })
                )
              );
            })
          )
        )
      );
    };

    this.store = _CastIronStore2.default;
  }

  handleDequeueSchedule(tx, event) {
    _CastIronActions2.default.dequeueSchedule(tx);
  }

  handScheduleTxInQueue(tx, event) {
    _CastIronActions2.default.scheduleTxInQueue(tx);
    event.target.blur();
  }

}

exports.default = ScheduleTxQList;