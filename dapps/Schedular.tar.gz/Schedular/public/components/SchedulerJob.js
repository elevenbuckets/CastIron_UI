"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _CastIronStore = require("../../../../public/store/CastIronStore");

var _CastIronStore2 = _interopRequireDefault(_CastIronStore);

var _CastIronService = require("../../../../public/service/CastIronService");

var _CastIronService2 = _interopRequireDefault(_CastIronService);

var _reflux = require("reflux");

var _reflux2 = _interopRequireDefault(_reflux);

var _react = require("react");

var _react2 = _interopRequireDefault(_react);

var _reactDropdown = require("react-dropdown");

var _reactDropdown2 = _interopRequireDefault(_reactDropdown);

var _CastIronActions = require("../../../../public/action/CastIronActions");

var _CastIronActions2 = _interopRequireDefault(_CastIronActions);

var _TxObjects = require("../../../../public/view/TxObjects");

var _TxObjects2 = _interopRequireDefault(_TxObjects);

var _ScheduleTxQList = require("./ScheduleTxQList");

var _ScheduleTxQList2 = _interopRequireDefault(_ScheduleTxQList);

var _Utils = require("../../../../public/util/Utils");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class SchedulerJob extends _reflux2.default.Component {
    constructor(props) {
        super(props);

        this.handleSchedule = (addr, type, amount, gasNumber) => {
            _CastIronActions2.default.schedule(this.state.address, addr, type, amount, gasNumber);
        };

        this.handleChange = event => {
            let addr = event.target.value;
            console.log('got addr: ' + addr);
            try {
                if (_CastIronService2.default.wallet.web3.isAddress(addr) === true && (_CastIronService2.default.wallet.web3.toAddress(addr) == addr || _CastIronService2.default.wallet.web3.toChecksumAddress(addr) == addr)) {
                    addr = _CastIronService2.default.wallet.web3.toAddress(addr);
                    (0, _Utils.createCanvasWithAddress)(this.refs.canvas, addr);
                } else {
                    this.refs.canvas.getContext('2d').clearRect(0, 0, this.refs.canvas.width, this.refs.canvas.height);
                }
            } catch (err) {
                this.refs.canvas.getContext('2d').clearRect(0, 0, this.refs.canvas.width, this.refs.canvas.height);
            }

            (0, _Utils.setDappLocalState)(this, { recipient: addr });
        };

        this.back = () => {
            this.props.goTo("List");
            if (this.props.viewType == "Edit") {
                this.props.cleanEdit();
            }
        };

        this.render = () => {
            return _react2.default.createElement(
                "div",
                null,
                _react2.default.createElement(
                    "table",
                    { className: "balance-sheet" },
                    _react2.default.createElement(
                        "tbody",
                        null,
                        _react2.default.createElement(
                            "tr",
                            { className: "avatar", style: { textAlign: "center" } },
                            _react2.default.createElement(
                                "th",
                                { colSpan: "2", className: "avatar", style: { textAlign: "center" } },
                                "Schedular"
                            )
                        ),
                        _react2.default.createElement(
                            "tr",
                            { className: "balance-sheet" },
                            _react2.default.createElement(
                                "td",
                                { className: "balance-sheet" },
                                _react2.default.createElement(
                                    "label",
                                    null,
                                    "Recipient:",
                                    _react2.default.createElement("input", { size: 62, style: { marginLeft: '30', fontFamily: 'monospace', fontSize: '1.09em' }, type: "text",
                                        onChange: this.handleChange, value: this.state.dappLocal.recipient, placeholder: "Ethereum Address" })
                                )
                            ),
                            _react2.default.createElement(
                                "td",
                                { className: "balance-sheet", width: 211, rowSpan: "2", style: { backgroundColor: '#eeeeee' } },
                                _react2.default.createElement(
                                    "table",
                                    { className: "txform" },
                                    _react2.default.createElement(
                                        "tbody",
                                        null,
                                        _react2.default.createElement(
                                            "tr",
                                            { className: "txform" },
                                            _react2.default.createElement(
                                                "td",
                                                { className: "txform", style: { textAlign: 'center' } },
                                                _react2.default.createElement("canvas", { ref: "canvas", width: 66, height: 66, style: {
                                                        border: "3px solid #ccc",
                                                        borderBottomLeftRadius: "2.8em",
                                                        borderBottomRightRadius: "2.8em",
                                                        borderTopRightRadius: "2.8em",
                                                        borderTopLeftRadius: "2.8em"
                                                    }
                                                })
                                            )
                                        )
                                    )
                                )
                            )
                        ),
                        _react2.default.createElement(
                            "tr",
                            { className: "balance-sheet" },
                            _react2.default.createElement(
                                "td",
                                { className: "balance-sheet" },
                                _react2.default.createElement(_TxObjects2.default, { selected_token_name: this.state.selected_token_name,
                                    handleEnqueue: this.handleEnqueueSchedule, handleSend: this.handleSchedule,
                                    recipient: this.state.dappLocal.recipient, send_button_value: "Schedule" })
                            )
                        )
                    )
                ),
                _react2.default.createElement(_ScheduleTxQList2.default, { style: { marginTop: '0', marginBottom: '0', paddingTop: '0', paddingBottom: '0' } }),
                _react2.default.createElement(
                    "div",
                    { style: {
                            textAlign: 'center',
                            backgroundColor: '#ffffff',
                            width: '100%',
                            maxHeight: '58',
                            minHeight: '58',
                            zIndex: '1',
                            position: "fixed",
                            bottom: '20%',
                            boxShadow: '0 -5px 6px -5px rgba(200,200,200,0.5)'
                        } },
                    _react2.default.createElement("input", { type: "button", className: "button", value: "BatchSchedule", onClick: this.handleBatchSchedule, style: { width: '160px', marginTop: '19px', marginLeft: '5%', marginRight: '5%' } }),
                    _react2.default.createElement("input", { type: "button", className: "button", value: "ClearAll", onClick: this.handleClearQueue, style: { backgroundColor: 'rgb(250,0,0)', width: '160px', marginTop: '19px', marginLeft: '5%', marginRight: '5%' } }),
                    _react2.default.createElement("input", { type: "button", className: "button", value: "Back", onClick: this.back, style: { width: '160px', marginTop: '19px', marginLeft: '5%', marginRight: '5%' } })
                )
            );
        };

        this.store = _CastIronStore2.default;
        this.state = {
            dappLocal: {
                recipient: ''
            }
        };
        this.wallet = _CastIronService2.default.wallet;
        this.timeout;
    }

    handleEnqueueSchedule(tx) {
        _CastIronActions2.default.enqueueSchedule(tx);
    }

    handleDequeueSchedule(tx) {
        _CastIronActions2.default.dequeueScheudle(tx);
    }

    handleClearQueueSchedule() {
        _CastIronActions2.default.clearQueueschedule();
    }

    handleBatchSchedule() {
        _CastIronActions2.default.batchSchedule();
    }

}

exports.default = SchedulerJob;