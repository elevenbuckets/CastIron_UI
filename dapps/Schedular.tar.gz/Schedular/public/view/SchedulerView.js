"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _CastIronStore = require("../../../../public/store/CastIronStore");

var _CastIronStore2 = _interopRequireDefault(_CastIronStore);

var _CastIronService = require("../../../../public/service/CastIronService");

var _CastIronService2 = _interopRequireDefault(_CastIronService);

var _reflux = require("reflux");

var _reflux2 = _interopRequireDefault(_reflux);

var _react = require("react");

var _react2 = _interopRequireDefault(_react);

var _reactDropdown = require("react-dropdown");

var _reactDropdown2 = _interopRequireDefault(_reactDropdown);

var _CastIronActions = require("../../../../public/action/CastIronActions");

var _CastIronActions2 = _interopRequireDefault(_CastIronActions);

var _TxObjects = require("../../../../public/view/TxObjects");

var _TxObjects2 = _interopRequireDefault(_TxObjects);

var _TxQList = require("../../../../public/view/TxQList");

var _TxQList2 = _interopRequireDefault(_TxQList);

var _Utils = require("../../../../public/util/Utils");

var _SchedulerJob = require("../components/SchedulerJob");

var _SchedulerJob2 = _interopRequireDefault(_SchedulerJob);

var _EditScheduleTXModal = require("../../../../public/components/EditScheduleTXModal");

var _EditScheduleTXModal2 = _interopRequireDefault(_EditScheduleTXModal);

var _Scheduler = require("../../../../public/util/Scheduler");

var _Scheduler2 = _interopRequireDefault(_Scheduler);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class SchedulerView extends _reflux2.default.Component {
    constructor(props) {
        super(props);

        this.componentDidMount = () => {
            (0, _Utils.setDappLocalState)(this, { filteredQs: this.state.scheduledQs });
        };

        this.componnentDidUpdate = (prevProps, prevState) => {
            if (prevState.scheduledQs != this.state.scheduledQs) {
                let filteredQs = this.state.scheduledQs;
                let filter = this.state.dappLocal.filter;
                // filteredQs = filteredQs.filter(q => {
                //     return JSON.stringify(q) == JSON.stringify({ ...q, ...this.state.dappLocal.filter });
                // })
                filteredQs = filteredQs.filter(q => {
                    return Object.keys(filter).reduce((match, key) => {
                        return match && q[key].includes(filter[key]);
                    }, true);
                    // return JSON.stringify(q) == JSON.stringify({ ...q, ...filter });
                });
                (0, _Utils.setDappLocalState)(this, { filteredQs: filteredQs });
            }
        };

        this.saveScheduleTX = Q => {
            // Use Schedule now, need to figure out how to change from state
            _Scheduler2.default.state.Qs.map(q => {
                if (q.Qid == Q.Qid) {
                    Object.keys(q).map(key => {
                        q[key] = Q[key];
                    });
                }
            });

            this.goTo("List");
        };

        this.cancelChangeScheduleTX = () => {
            this.goTo("List");
        };

        this.goTo = view => {
            (0, _Utils.setDappLocalState)(this, { schedulerViewType: view });
        };

        this.getActiveTaskNumber = () => {
            return this.state.dappLocal.filteredQs.length;
        };

        this.checked = (Q, event) => {
            if (event.target.checked) {
                (0, _Utils.setDappLocalState)(this, { selectedQs: [...this.state.dappLocal.selectedQs, Q] });
            } else {
                if (this.state.dappLocal.selectedQs.indexOf(Q) != -1) {
                    this.state.dappLocal.selectedQs.splice(this.state.dappLocal.selectedQs.indexOf(Q), 1);
                    (0, _Utils.setDappLocalState)(this, { selectedQs: this.state.dappLocal.selectedQs });
                }
            }
        };

        this.delete = () => {
            // 
            // this.state.dappLocal.selectedQs.map(Q => {
            //     if(Scheduler.state.Qs.indexOf(Q) != -1){
            //         Scheduler.state.Qs.splice(Scheduler.state.Qs.indexOf(Q), 1);
            //         CastIronActions.deleteScheduledQ(Q);
            //     }

            // })
            let cloneQs = [...this.state.dappLocal.selectedQs];
            _Scheduler2.default.deleteQs(cloneQs);
            _CastIronActions2.default.deleteScheduledQs(cloneQs);
            (0, _Utils.setDappLocalState)(this, { selectedQs: [] });
        };

        this.changeFilter = (field, event) => {
            let filter = _extends({}, this.state.dappLocal.filter, { [field]: event.target.value });
            if (event.target.value == "") {
                delete filter[field];
            }
            let filteredQs = this.state.scheduledQs;
            filteredQs = filteredQs.filter(q => {
                return Object.keys(filter).reduce((match, key) => {
                    return match && q[key].includes(filter[key]);
                }, true);
                // return JSON.stringify(q) == JSON.stringify({ ...q, ...filter });
            });
            (0, _Utils.setDappLocalState)(this, { filter: filter, filteredQs: filteredQs });
        };

        this.toggleSearch = () => {
            (0, _Utils.setDappLocalState)(this, { showSearch: !this.state.dappLocal.showSearch });
        };

        this.getQsComponent = () => {
            if (this.state.dappLocal.filteredQs) {
                return this.state.dappLocal.filteredQs.map(q => {
                    return _react2.default.createElement(
                        "tr",
                        { className: "balance-sheet" },
                        _react2.default.createElement(
                            "td",
                            { className: "balance-sheet",
                                width: "5%" },
                            _react2.default.createElement("input", {
                                name: "check",
                                type: "checkbox",
                                checked: this.state.dappLocal.selectedQs.includes(q),
                                onChange: this.checked.bind(this, q),
                                style: { width: "25px", height: "25px" } })
                        ),
                        _react2.default.createElement(
                            "td",
                            { className: "balance-sheet",
                                width: "30%" },
                            q.Qid
                        ),
                        _react2.default.createElement(
                            "td",
                            { className: "balance-sheet",
                                width: "20%" },
                            q.name
                        ),
                        _react2.default.createElement(
                            "td",
                            { className: "balance-sheet",
                                width: "20%" },
                            q.trigger
                        ),
                        _react2.default.createElement(
                            "td",
                            { className: "balance-sheet",
                                width: "10%" },
                            q.target
                        ),
                        _react2.default.createElement(
                            "td",
                            { className: "balance-sheet",
                                width: "5%" },
                            q.tolerance
                        ),
                        _react2.default.createElement(
                            "td",
                            { className: "balance-sheet",
                                width: "10%" },
                            q.status
                        )
                    );
                });
            }
        };

        this.render = () => {
            return this.state.dappLocal.schedulerViewType != "New" ? _react2.default.createElement(
                "div",
                null,
                _react2.default.createElement(
                    "table",
                    { className: "balance-sheet" },
                    _react2.default.createElement(
                        "tbody",
                        null,
                        _react2.default.createElement(
                            "tr",
                            { className: "avatar", style: { textAlign: "center" } },
                            _react2.default.createElement(
                                "th",
                                { colSpan: "2", className: "avatar", style: { textAlign: "center" } },
                                "Schedular"
                            )
                        ),
                        _react2.default.createElement(
                            "tr",
                            { className: "balance-sheet" },
                            _react2.default.createElement(
                                "td",
                                { className: "txform", style: { border: '0', textAlign: "left" } },
                                _react2.default.createElement("input", { type: "button", className: "bbutton", value: "New", onClick: this.goTo.bind(this, "New") }),
                                _react2.default.createElement("input", { type: "button", className: "bbutton", value: "Edit", onClick: this.goTo.bind(this, "Edit"),
                                    disabled: this.state.dappLocal.selectedQs.length != 1 }),
                                _react2.default.createElement("input", { type: "button", className: "bbutton", value: "Search", onClick: this.toggleSearch }),
                                _react2.default.createElement("input", { type: "button", className: "bbutton", value: "Delete", onClick: this.delete,
                                    disabled: this.state.dappLocal.selectedQs.length == 0 })
                            ),
                            _react2.default.createElement(
                                "td",
                                { className: "txform", style: { border: '0', textAlign: "center" } },
                                _react2.default.createElement(
                                    "p",
                                    null,
                                    "Active Tasks: ",
                                    this.getActiveTaskNumber()
                                )
                            )
                        )
                    )
                ),
                _react2.default.createElement(
                    "div",
                    { style: { overflow: 'scroll', margin: '0', maxHeight: "490px", height: '490px' } },
                    _react2.default.createElement(
                        "table",
                        { className: "balance-sheet" },
                        _react2.default.createElement(
                            "tbody",
                            null,
                            _react2.default.createElement(
                                "tr",
                                { className: "balance-sheet" },
                                _react2.default.createElement(
                                    "th",
                                    { className: "balance-sheet", style: { color: '#111111' }, width: "5%" },
                                    "Select"
                                ),
                                _react2.default.createElement(
                                    "th",
                                    { className: "balance-sheet", style: { color: '#111111' }, width: "30%" },
                                    "Qid"
                                ),
                                _react2.default.createElement(
                                    "th",
                                    { className: "balance-sheet", style: { color: '#111111' }, width: "20%" },
                                    "Name"
                                ),
                                _react2.default.createElement(
                                    "th",
                                    { className: "balance-sheet", style: { color: '#111111' }, width: "20%" },
                                    "Trigger"
                                ),
                                _react2.default.createElement(
                                    "th",
                                    { className: "balance-sheet", style: { color: '#111111' }, width: "10%" },
                                    "Target"
                                ),
                                _react2.default.createElement(
                                    "th",
                                    { className: "balance-sheet", style: { color: '#111111' }, width: "5%" },
                                    "Tolerance"
                                ),
                                _react2.default.createElement(
                                    "th",
                                    { className: "balance-sheet", style: { color: '#111111' }, width: "10%" },
                                    "Status"
                                )
                            ),
                            _react2.default.createElement(
                                "tr",
                                { className: "balance-sheet", style: { textAlign: "center" } },
                                _react2.default.createElement(
                                    "th",
                                    { colSpan: "7", className: "balance-sheet", style: { textAlign: "center" }, hidden: "true" },
                                    "Color Swap"
                                )
                            ),
                            _react2.default.createElement(
                                "tr",
                                { className: "balance-sheet", hidden: !this.state.dappLocal.showSearch },
                                _react2.default.createElement("td", { className: "balance-sheet",
                                    width: "5%" }),
                                _react2.default.createElement(
                                    "td",
                                    { className: "balance-sheet",
                                        width: "30%" },
                                    _react2.default.createElement("input", { type: "text", size: "36",
                                        onChange: this.changeFilter.bind(this, "Qid")
                                    })
                                ),
                                _react2.default.createElement(
                                    "td",
                                    { className: "balance-sheet",
                                        width: "20%" },
                                    _react2.default.createElement("input", { type: "text", size: "20",
                                        onChange: this.changeFilter.bind(this, "name")
                                    })
                                ),
                                _react2.default.createElement(
                                    "td",
                                    { className: "balance-sheet",
                                        width: "20%" },
                                    _react2.default.createElement("input", { type: "text", size: "20",
                                        onChange: this.changeFilter.bind(this, "trigger")
                                    })
                                ),
                                _react2.default.createElement(
                                    "td",
                                    { className: "balance-sheet",
                                        width: "10%" },
                                    _react2.default.createElement("input", { type: "text", size: "10",
                                        onChange: this.changeFilter.bind(this, "target")
                                    })
                                ),
                                _react2.default.createElement(
                                    "td",
                                    { className: "balance-sheet",
                                        width: "5%" },
                                    _react2.default.createElement("input", { type: "text", size: "5",
                                        onChange: this.changeFilter.bind(this, "tolerance")
                                    })
                                ),
                                _react2.default.createElement(
                                    "td",
                                    { className: "balance-sheet",
                                        width: "10%" },
                                    _react2.default.createElement("input", { type: "text", size: "10",
                                        onChange: this.changeFilter.bind(this, "status")
                                    })
                                )
                            ),
                            this.getQsComponent()
                        )
                    ),
                    _react2.default.createElement(
                        "div",
                        { style: {
                                textAlign: 'center',
                                backgroundColor: '#ffffff',
                                width: '99.5%',
                                maxHeight: '58',
                                minHeight: '58',
                                zIndex: '2',
                                position: "fixed",
                                bottom: '20%',
                                boxShadow: '0 -5px 6px -5px rgba(200,200,200,0.5)'
                            } },
                        _react2.default.createElement("input", { type: "text", style: { paddingTop: '15px', fontFamily: 'monospace', border: 0, width: '85%', fontSize: '1.11em', textAlign: 'center' }, align: "center", ref: "infocache", value: "" })
                    )
                ),
                this.state.dappLocal.selectedQs.length == 0 ? '' : _react2.default.createElement(_EditScheduleTXModal2.default, { saveScheduleTX: this.saveScheduleTX, cancelChangeScheduleTX: this.cancelChangeScheduleTX,
                    Q: this.state.dappLocal.selectedQs[0],
                    isEditScheduleModalOpen: this.state.dappLocal.schedulerViewType == "Edit", gasPrice: this.state.gasPrice })
            ) : this.state.dappLocal.schedulerViewType == "New" ? _react2.default.createElement(_SchedulerJob2.default, { viewType: this.state.dappLocal.schedulerViewType,
                goTo: this.goTo }) : _react2.default.createElement(_SchedulerJob2.default, { goTo: this.goTo, cleanEdit: this.cleanEdit, viewType: this.state.dappLocal.schedulerViewType, Q: this.state.dappLocal.selectedQs.length == 0 ? null : this.state.dappLocal.selectedQs[0] });
        };

        this.store = _CastIronStore2.default;
        this.state = {
            dappLocal: {
                recipient: '',
                schedulerViewType: "List", // Options are List, New, Edit
                selectedQs: [],
                filteredQs: [],
                filter: {},
                showSearch: false
            }

        };
        this.wallet = _CastIronService2.default.wallet;
    }

    cleanEdit() {
        _CastIronActions2.default.clearQueueSchedule();
        (0, _Utils.setDappLocalState)(this, { selectedQs: [] });
    }

}

exports.default = SchedulerView;